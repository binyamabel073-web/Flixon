package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Color Theme (Elegant Material 3 Amethyst & Slate)
val MinimalBackground = Color(0xFF1C1B1F)
val MinimalPrimary = Color(0xFFD0BCFF)
val MinimalSecondary = Color(0xFF4A4458)
val MinimalTertiary = Color(0xFFE8DEF8)
val MinimalOnPrimary = Color(0xFF381E72)
val MinimalTextPrimary = Color(0xFFE6E1E5)
val MinimalTextSecondary = Color(0xFFCAC4D0)
val MinimalTextMuted = Color(0xFF938F99)
val MinimalSurface = Color(0xFF2B2930)
