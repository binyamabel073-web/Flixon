package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "addons")
data class AddonEntity(
    @PrimaryKey val url: String,
    val id: String,
    val version: String,
    val name: String,
    val description: String?,
    val icon: String?,
    val logo: String?,
    val types: String, // Comma-separated
    val resources: String, // Comma-separated
    val catalogsJson: String, // JSON string
    val isEnabled: Boolean = true
)

@Entity(tableName = "watch_items")
data class WatchItemEntity(
    @PrimaryKey val id: String, // IMDb ID
    val type: String, // "movie" or "series"
    val name: String,
    val poster: String?,
    val background: String?,
    val rating: String?,
    val genres: String?, // Comma-separated
    val description: String?,
    val lastWatchedEpisodeId: String? = null,
    val lastWatchedTime: Long = 0L,
    val isFavorite: Boolean = false,
    val progress: Float = 0.0f
)

@Dao
interface AddonDao {
    @Query("SELECT * FROM addons")
    fun getAllAddonsFlow(): Flow<List<AddonEntity>>

    @Query("SELECT * FROM addons")
    suspend fun getAllAddons(): List<AddonEntity>

    @Query("SELECT * FROM addons WHERE isEnabled = 1")
    suspend fun getEnabledAddons(): List<AddonEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAddon(addon: AddonEntity)

    @Query("DELETE FROM addons WHERE url = :url")
    suspend fun deleteAddon(url: String)

    @Query("UPDATE addons SET isEnabled = :isEnabled WHERE url = :url")
    suspend fun updateAddonStatus(url: String, isEnabled: Boolean)
}

@Dao
interface WatchItemDao {
    @Query("SELECT * FROM watch_items WHERE isFavorite = 1 ORDER BY lastWatchedTime DESC")
    fun getFavoritesFlow(): Flow<List<WatchItemEntity>>

    @Query("SELECT * FROM watch_items WHERE lastWatchedTime > 0 ORDER BY lastWatchedTime DESC")
    fun getHistoryFlow(): Flow<List<WatchItemEntity>>

    @Query("SELECT * FROM watch_items WHERE id = :id")
    suspend fun getWatchItemById(id: String): WatchItemEntity?

    @Query("SELECT * FROM watch_items WHERE id = :id")
    fun getWatchItemByIdFlow(id: String): Flow<WatchItemEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWatchItem(item: WatchItemEntity)

    @Query("DELETE FROM watch_items WHERE id = :id")
    suspend fun deleteWatchItem(id: String)
}

@Database(entities = [AddonEntity::class, WatchItemEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun addonDao(): AddonDao
    abstract fun watchItemDao(): WatchItemDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "flixon_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
