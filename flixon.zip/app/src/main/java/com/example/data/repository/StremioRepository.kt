package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.local.AddonDao
import com.example.data.local.AddonEntity
import com.example.data.local.AppDatabase
import com.example.data.local.WatchItemDao
import com.example.data.local.WatchItemEntity
import com.example.data.model.StremioAddonManifest
import com.example.data.model.StremioCatalog
import com.example.data.model.StremioMetaDetail
import com.example.data.model.StremioMetaItem
import com.example.data.model.StremioStream
import com.example.data.remote.StremioHttpClient
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

class StremioRepository(
    private val addonDao: AddonDao,
    private val watchItemDao: WatchItemDao
) {
    companion object {
        private const val TAG = "StremioRepository"
        
        // Default Cinemeta metadata addon URL
        const val DEFAULT_ADDON_URL = "https://v3-cinemeta.strem.io/manifest.json"
        
        // TMDB metadata addon URL
        const val TMDB_ADDON_URL = "https://tmdb-addon.strem.io/manifest.json"
        
        // Recommended addon suggestions
        val RECOMMENDATIONS = listOf(
            Pair("Cinemeta (Official Movies & Series Metadata)", "https://v3-cinemeta.strem.io/manifest.json"),
            Pair("The Movie Database (TMDB - Alternative Metadata)", "https://tmdb-addon.strem.io/manifest.json"),
            Pair("Torrentio (Provides almost all stream sources)", "https://torrentio.strem.fun/manifest.json"),
            Pair("CyberFlix Catalog (Popular Streaming Catalogs)", "https://cyberflix.strem.io/manifest.json"),
            Pair("YouTube (Trailers & Clips)", "https://v3-youtube.strem.io/manifest.json"),
            Pair("WatchHub (Official Rent/Buy Streams)", "https://watchhub.strem.io/manifest.json"),
            Pair("Twitch (Live Game Streams)", "https://twitch.strem.io/manifest.json")
        )
    }

    val allAddonsFlow: Flow<List<AddonEntity>> = addonDao.getAllAddonsFlow()
    val favoritesFlow: Flow<List<WatchItemEntity>> = watchItemDao.getFavoritesFlow()
    val historyFlow: Flow<List<WatchItemEntity>> = watchItemDao.getHistoryFlow()

    /**
     * Initializes default addons if database is empty.
     */
    suspend fun initDefaultAddons() {
        val currentAddons = addonDao.getAllAddons()
        val currentUrls = currentAddons.map { it.url }
        
        if (!currentUrls.contains(DEFAULT_ADDON_URL)) {
            Log.d(TAG, "Initializing default Cinemeta addon...")
            installAddon(DEFAULT_ADDON_URL)
        }
        
        if (!currentUrls.contains(TMDB_ADDON_URL)) {
            Log.d(TAG, "Initializing default TMDB addon...")
            installAddon(TMDB_ADDON_URL)
        }
    }

    /**
     * Installs a Stremio addon from its manifest URL.
     */
    suspend fun installAddon(url: String): Boolean {
        try {
            val manifest = StremioHttpClient.fetchManifest(url) ?: return false
            
            // Map catalogs to JSON string
            val catalogsArray = JSONArray()
            manifest.catalogs.forEach { cat ->
                val catObj = JSONObject().apply {
                    put("type", cat.type)
                    put("id", cat.id)
                    put("name", cat.name)
                    
                    val extraArray = JSONArray()
                    cat.extra.forEach { ext ->
                        val extObj = JSONObject().apply {
                            put("name", ext.name)
                            put("isRequired", ext.isRequired)
                            if (ext.options != null) {
                                put("options", JSONArray(ext.options))
                            }
                        }
                        extraArray.put(extObj)
                    }
                    put("extra", extraArray)
                }
                catalogsArray.put(catObj)
            }

            val entity = AddonEntity(
                url = manifest.url,
                id = manifest.id,
                version = manifest.version,
                name = manifest.name,
                description = manifest.description,
                icon = manifest.icon,
                logo = manifest.logo,
                types = manifest.types.joinToString(","),
                resources = manifest.resources.joinToString(","),
                catalogsJson = catalogsArray.toString(),
                isEnabled = true
            )
            
            addonDao.insertAddon(entity)
            Log.d(TAG, "Successfully installed addon: ${manifest.name}")
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to install addon from url $url", e)
            return false
        }
    }

    suspend fun deleteAddon(url: String) {
        addonDao.deleteAddon(url)
    }

    suspend fun toggleAddon(url: String, isEnabled: Boolean) {
        addonDao.updateAddonStatus(url, isEnabled)
    }

    /**
     * Parses the catalogs stored in JSON format for an addon entity.
     */
    fun parseCatalogs(entity: AddonEntity): List<StremioCatalog> {
        val list = mutableListOf<StremioCatalog>()
        try {
            if (entity.catalogsJson.isNotEmpty()) {
                val arr = JSONArray(entity.catalogsJson)
                for (i in 0 until arr.length()) {
                    list.add(StremioCatalog.fromJson(arr.getJSONObject(i)))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing catalogs for ${entity.name}", e)
        }
        return list
    }

    /**
     * Fetches metadata catalog items across all enabled metadata addons.
     */
    suspend fun getCatalogItems(
        type: String,
        catalogId: String,
        searchQuery: String? = null
    ): List<StremioMetaItem> {
        val enabledAddons = addonDao.getEnabledAddons()
        val items = mutableListOf<StremioMetaItem>()
        
        // Find addons that support "catalog" resource and the requested content type
        val matchingAddons = enabledAddons.filter { addon ->
            val hasCatalogRes = addon.resources.split(",").contains("catalog")
            val supportsType = addon.types.split(",").contains(type)
            hasCatalogRes && supportsType
        }

        for (addon in matchingAddons) {
            // Check if catalogId exists in this addon's catalogs
            val catalogs = parseCatalogs(addon)
            val hasCatalog = catalogs.any { it.id == catalogId } || !searchQuery.isNullOrBlank()
            if (hasCatalog) {
                val fetched = StremioHttpClient.fetchCatalog(addon.url, type, catalogId, searchQuery)
                if (fetched.isNotEmpty()) {
                    // Combine results and avoid duplicates based on ID
                    fetched.forEach { item ->
                        if (items.none { it.id == item.id }) {
                            items.add(item)
                        }
                    }
                }
            }
        }

        // If nothing found and searching, fall back to searching Cinemeta directly
        if (items.isEmpty() && !searchQuery.isNullOrBlank()) {
            val cinemetaUrl = DEFAULT_ADDON_URL
            val fetched = StremioHttpClient.fetchCatalog(cinemetaUrl, type, "top", searchQuery)
            return fetched
        }

        return items
    }

    /**
     * Fetches details of a specific item (Movie or Series).
     */
    suspend fun getMetaDetail(type: String, id: String): StremioMetaDetail? {
        val enabledAddons = addonDao.getEnabledAddons()
        
        // Filter addons supporting "meta" resource
        val matchingAddons = enabledAddons.filter { addon ->
            val hasMetaRes = addon.resources.split(",").contains("meta")
            val supportsType = addon.types.split(",").contains(type)
            hasMetaRes && supportsType
        }

        // Try matched addons first
        for (addon in matchingAddons) {
            val detail = StremioHttpClient.fetchMetaDetail(addon.url, type, id)
            if (detail != null) return detail
        }

        // Fallback to Cinemeta
        return StremioHttpClient.fetchMetaDetail(DEFAULT_ADDON_URL, type, id)
    }

    /**
     * Aggregates stream results for a video item from all enabled stream addons.
     */
    suspend fun getStreams(type: String, id: String): List<StremioStream> {
        val enabledAddons = addonDao.getEnabledAddons()
        val streams = mutableListOf<StremioStream>()

        // Filter addons supporting "stream" resource
        val streamAddons = enabledAddons.filter { addon ->
            addon.resources.split(",").contains("stream") && 
            addon.types.split(",").contains(type)
        }

        for (addon in streamAddons) {
            val fetched = StremioHttpClient.fetchStreams(addon.url, type, id, addon.name)
            streams.addAll(fetched)
        }

        return streams
    }

    // --- WatchList and History Persistence ---

    fun getWatchItemFlow(id: String): Flow<WatchItemEntity?> {
        return watchItemDao.getWatchItemByIdFlow(id)
    }

    suspend fun toggleFavorite(detail: StremioMetaDetail): Boolean {
        val existing = watchItemDao.getWatchItemById(detail.id)
        val isFav = !(existing?.isFavorite ?: false)
        
        val updated = WatchItemEntity(
            id = detail.id,
            type = detail.type,
            name = detail.name,
            poster = detail.poster,
            background = detail.background,
            rating = detail.imdbRating,
            genres = detail.genres.joinToString(","),
            description = detail.description,
            lastWatchedEpisodeId = existing?.lastWatchedEpisodeId,
            lastWatchedTime = existing?.lastWatchedTime ?: 0L,
            isFavorite = isFav,
            progress = existing?.progress ?: 0.0f
        )
        watchItemDao.insertWatchItem(updated)
        return isFav
    }

    suspend fun saveToHistory(
        id: String,
        type: String,
        name: String,
        poster: String?,
        background: String?,
        rating: String?,
        genres: String?,
        description: String?,
        episodeId: String? = null,
        progress: Float = 0.0f
    ) {
        val existing = watchItemDao.getWatchItemById(id)
        val item = WatchItemEntity(
            id = id,
            type = type,
            name = name,
            poster = poster,
            background = background,
            rating = rating,
            genres = genres,
            description = description,
            lastWatchedEpisodeId = episodeId ?: existing?.lastWatchedEpisodeId,
            lastWatchedTime = System.currentTimeMillis(),
            isFavorite = existing?.isFavorite ?: false,
            progress = progress
        )
        watchItemDao.insertWatchItem(item)
    }

    suspend fun getCommunityAddons(): List<StremioAddonManifest> {
        return StremioHttpClient.fetchCommunityAddons()
    }
}
